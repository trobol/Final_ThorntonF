﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NEAT
{
	public class Network
	{
		Network(Genome g)
		{

		}
	}
}
