﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridObject : MonoBehaviour
{
	public int x, y;
	GridManager gridManager;
	public void MoveTo(int x1, int y1)
	{

	}
}
