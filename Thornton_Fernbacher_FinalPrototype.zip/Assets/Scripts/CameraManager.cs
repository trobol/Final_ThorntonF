﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraManager : MonoBehaviour
{

	void Start()
	{

	}

	void Update()
	{

	}

	void MoveTo(Vector2 pos)
	{

	}


	void MoveToTime(Vector2 pos)
	{

	}

	void MoveToSpeed(Vector2 pos)
	{

	}
	float moveTime = 0;
	void MoveUpdate()
	{

	}
}
