﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridMaker : MonoBehaviour
{

	GameObject tile;
	public int width, height;

	void Start()
	{

	}


	void Update()
	{

	}
}
