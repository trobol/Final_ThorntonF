﻿
public class GameController
{
	public int shipCount = 2;
	Ship[] ships;

}
