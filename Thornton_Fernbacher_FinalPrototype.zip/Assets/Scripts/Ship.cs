class Ship
{
	public int x, y;

}

class AIShip : Ship
{

}

class PlayerShip : Ship
{

}